webpackHotUpdate("static/development/pages/main.js",{

/***/ "./pages/main.tsx":
/*!************************!*\
  !*** ./pages/main.tsx ***!
  \************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var antd_lib_time_picker__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! antd/lib/time-picker */ "./node_modules/antd/lib/time-picker/index.js");
/* harmony import */ var antd_lib_time_picker__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(antd_lib_time_picker__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var antd_lib_date_picker__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! antd/lib/date-picker */ "./node_modules/antd/lib/date-picker/index.js");
/* harmony import */ var antd_lib_date_picker__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd_lib_date_picker__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var antd_lib_row__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! antd/lib/row */ "./node_modules/antd/lib/row/index.js");
/* harmony import */ var antd_lib_row__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(antd_lib_row__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var antd_lib_list__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! antd/lib/list */ "./node_modules/antd/lib/list/index.js");
/* harmony import */ var antd_lib_list__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(antd_lib_list__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var antd_lib_button__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! antd/lib/button */ "./node_modules/antd/lib/button/index.js");
/* harmony import */ var antd_lib_button__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(antd_lib_button__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var antd_lib_col__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! antd/lib/col */ "./node_modules/antd/lib/col/index.js");
/* harmony import */ var antd_lib_col__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(antd_lib_col__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @babel/runtime/helpers/esm/classCallCheck */ "./node_modules/@babel/runtime/helpers/esm/classCallCheck.js");
/* harmony import */ var _babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @babel/runtime/helpers/esm/createClass */ "./node_modules/@babel/runtime/helpers/esm/createClass.js");
/* harmony import */ var _babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @babel/runtime/helpers/esm/assertThisInitialized */ "./node_modules/@babel/runtime/helpers/esm/assertThisInitialized.js");
/* harmony import */ var _babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @babel/runtime/helpers/esm/inherits */ "./node_modules/@babel/runtime/helpers/esm/inherits.js");
/* harmony import */ var _babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @babel/runtime/helpers/esm/possibleConstructorReturn */ "./node_modules/@babel/runtime/helpers/esm/possibleConstructorReturn.js");
/* harmony import */ var _babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @babel/runtime/helpers/esm/getPrototypeOf */ "./node_modules/@babel/runtime/helpers/esm/getPrototypeOf.js");
/* harmony import */ var _babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @babel/runtime/helpers/esm/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var antd_lib_input__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! antd/lib/input */ "./node_modules/antd/lib/input/index.js");
/* harmony import */ var antd_lib_input__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(antd_lib_input__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var antd_lib_modal__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! antd/lib/modal */ "./node_modules/antd/lib/modal/index.js");
/* harmony import */ var antd_lib_modal__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(antd_lib_modal__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var next_session__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! next-session */ "./node_modules/next-session/src/index.js");
/* harmony import */ var next_session__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(next_session__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @ant-design/icons */ "./node_modules/@ant-design/icons/es/index.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! next/router */ "./node_modules/next/dist/client/router.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var _public_css_antd_less__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ../public/css/antd.less */ "./public/css/antd.less");
/* harmony import */ var _public_css_antd_less__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(_public_css_antd_less__WEBPACK_IMPORTED_MODULE_22__);
















var _jsxFileName = "/Users/lee/git/electron.js/nextjs/pages/main.tsx";
var __jsx = react__WEBPACK_IMPORTED_MODULE_16___default.a.createElement;

function _createSuper(Derived) { return function () { var Super = Object(_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_12__["default"])(Derived), result; if (_isNativeReflectConstruct()) { var NewTarget = Object(_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_12__["default"])(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return Object(_babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_11__["default"])(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }




var confirm = antd_lib_modal__WEBPACK_IMPORTED_MODULE_15___default.a.confirm;
var Search = antd_lib_input__WEBPACK_IMPORTED_MODULE_14___default.a.Search;




axios__WEBPACK_IMPORTED_MODULE_18___default.a.defaults.baseURL = true ? 'http://localhost:3000' : undefined;
moment__WEBPACK_IMPORTED_MODULE_21___default.a.locale('ko', {
  weekdays: ['일요일', '월요일', '화요일', '수요일', '목요일', '금요일', '토요일'],
  weekdaysShort: ['일', '월', '화', '수', '목', '금', '토']
});

var Main = /*#__PURE__*/function (_React$Component) {
  Object(_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_10__["default"])(Main, _React$Component);

  var _super = _createSuper(Main);

  function Main(props) {
    var _this2;

    Object(_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_7__["default"])(this, Main);

    _this2 = _super.call(this, props);

    Object(_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_13__["default"])(Object(_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_9__["default"])(_this2), "newMemberNameInput", void 0);

    Object(_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_13__["default"])(Object(_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_9__["default"])(_this2), "newMemberPositionInput", void 0);

    Object(_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_13__["default"])(Object(_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_9__["default"])(_this2), "fetchInitialData", function _callee() {
      var rs, memberList;
      return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_6___default.a.async(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              _this2.setState({
                isLoading: true
              });

              _context.next = 3;
              return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_6___default.a.awrap(axios__WEBPACK_IMPORTED_MODULE_18___default.a.get('/api/member'));

            case 3:
              rs = _context.sent;
              memberList = rs.data.memberList;

              _this2.setState({
                isLoading: true,
                memberList: memberList
              }, function () {
                _this2.fetchAttendanceData();
              });

            case 6:
            case "end":
              return _context.stop();
          }
        }
      }, null, null, null, Promise);
    });

    Object(_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_13__["default"])(Object(_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_9__["default"])(_this2), "fetchAttendanceData", function () {
      var viewDate = _this2.state.viewDate;
      axios__WEBPACK_IMPORTED_MODULE_18___default.a.get('/api/attendance', {
        params: {
          date: viewDate.format('YYYY-MM')
        }
      }).then(function (_ref) {
        var data = _ref.data;
        data.attendanceData.memberAttendanceList = data.attendanceData.memberAttendanceList ? data.attendanceData.memberAttendanceList : [];

        _this2.setState({
          attendanceData: data.attendanceData,
          isLoading: false
        });
      });
    });

    Object(_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_13__["default"])(Object(_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_9__["default"])(_this2), "openModal", function _callee2() {
      var rs;
      return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_6___default.a.async(function _callee2$(_context2) {
        while (1) {
          switch (_context2.prev = _context2.next) {
            case 0:
              _context2.next = 2;
              return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_6___default.a.awrap(axios__WEBPACK_IMPORTED_MODULE_18___default.a.get('/api/member'));

            case 2:
              rs = _context2.sent;

              _this2.setState({
                memberList: rs.data.memberList,
                visible: true
              });

            case 4:
            case "end":
              return _context2.stop();
          }
        }
      }, null, null, null, Promise);
    });

    Object(_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_13__["default"])(Object(_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_9__["default"])(_this2), "modalHandleOk", function (e) {
      console.log(e);

      _this2.setState({
        visible: false
      });
    });

    Object(_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_13__["default"])(Object(_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_9__["default"])(_this2), "modalHandleCancel", function (e) {
      console.log(e);

      _this2.setState({
        visible: false
      });
    });

    Object(_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_13__["default"])(Object(_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_9__["default"])(_this2), "onChangeDatePicker", function (date) {
      _this2.setState({
        viewDate: date,
        isLoading: true
      }, function () {
        _this2.fetchAttendanceData();
      });
    });

    Object(_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_13__["default"])(Object(_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_9__["default"])(_this2), "onChangeTimePicker", function (time, memberAttendance, date, type) {
      var _this2$state = _this2.state,
          attendanceData = _this2$state.attendanceData,
          viewDate = _this2$state.viewDate;
      var memberAttendanceList = attendanceData.memberAttendanceList;
      var targetMemberAttendance;

      for (var i in memberAttendanceList) {
        if (memberAttendanceList[i].memberId === memberAttendance._id) {
          targetMemberAttendance = memberAttendanceList[i];
        }
      }

      if (!targetMemberAttendance) {
        targetMemberAttendance = {
          memberId: memberAttendance._id
        };
        memberAttendanceList.push(targetMemberAttendance);
      }

      targetMemberAttendance[date.format] = targetMemberAttendance[date.format] ? targetMemberAttendance[date.format] : {};
      targetMemberAttendance[date.format][type] = time;

      _this2.saveData(viewDate.format('YYYY-MM'), memberAttendanceList);
    });

    Object(_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_13__["default"])(Object(_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_9__["default"])(_this2), "saveData", function (date, memberAttendanceList) {
      _this2.setState({
        isLoading: true
      });

      axios__WEBPACK_IMPORTED_MODULE_18___default.a.post('/api/attendance', {
        date: date,
        memberAttendanceList: memberAttendanceList
      }).then(function (rs) {
        _this2.setState({
          isLoading: false
        });
      });
    });

    Object(_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_13__["default"])(Object(_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_9__["default"])(_this2), "addMember", function () {
      var name = _this2.newMemberNameInput.current.input.value;
      var position = _this2.newMemberPositionInput.current.input.value;

      if (name && position) {
        axios__WEBPACK_IMPORTED_MODULE_18___default.a.post('/api/member', {
          name: name,
          position: position
        }).then(function (rs) {
          console.log(rs);

          if (!rs.data.isErr) {
            _this2.state.memberList.push(rs.data.member);

            _this2.forceUpdate();
          }

          _this2.newMemberNameInput.current.state.value = '';
          _this2.newMemberPositionInput.current.state.value = '';
        });
      }
    });

    Object(_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_13__["default"])(Object(_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_9__["default"])(_this2), "showDeleteConfirm", function (id) {
      var _this = Object(_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_9__["default"])(_this2);

      confirm({
        title: '정말 삭제하시겠습니까?',
        icon: __jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_19__["ExclamationCircleOutlined"], {
          __self: Object(_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_9__["default"])(_this2),
          __source: {
            fileName: _jsxFileName,
            lineNumber: 203,
            columnNumber: 13
          }
        }),
        content: '복구될 수 없습니다.',
        okText: '확인',
        okType: 'danger',
        cancelText: '취소',
        onOk: function onOk() {
          axios__WEBPACK_IMPORTED_MODULE_18___default.a["delete"]('/api/member', {
            params: {
              id: id
            }
          }).then(function () {
            var memberList = _this.state.memberList;

            for (var i in memberList) {
              if (memberList[i]['_id'] === id) {
                memberList.splice(i, 1);

                _this.forceUpdate();

                break;
              }
            }
          });
        }
      });
    });

    _this2.state = {
      visible: false,
      isLoading: false,
      memberList: [],
      viewMemberList: [],
      viewDate: moment__WEBPACK_IMPORTED_MODULE_21___default()(),
      attendanceData: {
        date: moment__WEBPACK_IMPORTED_MODULE_21___default()().format('YYYY-MM'),
        memberAttendanceList: []
      }
    };
    _this2.newMemberNameInput = Object(react__WEBPACK_IMPORTED_MODULE_16__["createRef"])();
    _this2.newMemberPositionInput = Object(react__WEBPACK_IMPORTED_MODULE_16__["createRef"])();
    return _this2;
  }

  Object(_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_8__["default"])(Main, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      if (!this.props.user) {
        next_router__WEBPACK_IMPORTED_MODULE_20___default.a.push('/');
      } else {
        this.fetchInitialData();
      }
    }
  }, {
    key: "render",
    value: function render() {
      var _this3 = this;

      if (!this.props.user) {
        return false;
      }

      var username = this.props.user.username;
      var isAdmin = username === 'admin' ? true : false;
      var _this$state = this.state,
          memberList = _this$state.memberList,
          viewDate = _this$state.viewDate,
          visible = _this$state.visible,
          attendanceData = _this$state.attendanceData;
      var daysList = [];

      for (var i = 1; i <= viewDate.daysInMonth(); i++) {
        viewDate.date(i);
        daysList.push({
          number: viewDate.format('DD'),
          dayStr: viewDate.format('dddd'),
          day: viewDate.day(),
          format: viewDate.format('YYYY-MM-DD')
        });
      }

      var viewMemberList = memberList.slice();
      var memberAttendanceList = attendanceData.memberAttendanceList;
      viewMemberList.map(function (member) {
        var index = 0;
        var exist = memberAttendanceList.some(function (memberAttendance) {
          index++;
          return memberAttendance.memberId === member._id;
        });
        console.log(exist);

        if (exist) {
          index--;
          member.attendance = memberAttendanceList[index];
        } else {
          member.attendance = {
            memberId: member._id
          };
        }
      });
      return __jsx("div", {
        className: "main-page-wrap",
        __self: this,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 268,
          columnNumber: 7
        }
      }, __jsx(antd_lib_row__WEBPACK_IMPORTED_MODULE_2___default.a, {
        align: "middle",
        style: {
          padding: '16px 8px'
        },
        __self: this,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 269,
          columnNumber: 9
        }
      }, __jsx(antd_lib_col__WEBPACK_IMPORTED_MODULE_5___default.a, {
        className: "",
        span: "11",
        __self: this,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 270,
          columnNumber: 11
        }
      }, __jsx("img", {
        src: "/images/logo_horizontal.svg",
        style: {
          height: '40px',
          verticalAlign: 'middle'
        },
        __self: this,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 271,
          columnNumber: 13
        }
      }), __jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_19__["SyncOutlined"], {
        style: {
          fontSize: '25px',
          marginLeft: '15px',
          verticalAlign: 'middle'
        },
        spin: this.state.isLoading,
        __self: this,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 272,
          columnNumber: 13
        }
      })), __jsx(antd_lib_col__WEBPACK_IMPORTED_MODULE_5___default.a, {
        className: "text-right",
        offset: "4",
        span: "9",
        __self: this,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 277,
          columnNumber: 11
        }
      }, isAdmin ? __jsx(react__WEBPACK_IMPORTED_MODULE_16___default.a.Fragment, null, __jsx(antd_lib_button__WEBPACK_IMPORTED_MODULE_4___default.a, {
        style: {
          marginRight: '5px'
        },
        type: "primary",
        onClick: this.openModal,
        __self: this,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 280,
          columnNumber: 17
        }
      }, "\uAD6C\uC131\uC6D0 \uAD00\uB9AC"), __jsx(antd_lib_modal__WEBPACK_IMPORTED_MODULE_15___default.a, {
        title: "\uAD6C\uC131\uC6D0 \uAD00\uB9AC",
        visible: visible,
        onOk: this.modalHandleOk,
        onCancel: this.modalHandleCancel,
        okText: "\uD655\uC778",
        cancelText: "\uB2EB\uAE30",
        __self: this,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 283,
          columnNumber: 17
        }
      }, __jsx(antd_lib_list__WEBPACK_IMPORTED_MODULE_3___default.a, {
        size: "small",
        bordered: true,
        dataSource: memberList,
        renderItem: function renderItem(_ref2) {
          var name = _ref2.name,
              position = _ref2.position,
              _id = _ref2._id;
          return __jsx(antd_lib_list__WEBPACK_IMPORTED_MODULE_3___default.a.Item, {
            key: _id,
            className: "clearfix",
            __self: _this3,
            __source: {
              fileName: _jsxFileName,
              lineNumber: 296,
              columnNumber: 23
            }
          }, __jsx(antd_lib_col__WEBPACK_IMPORTED_MODULE_5___default.a, {
            __self: _this3,
            __source: {
              fileName: _jsxFileName,
              lineNumber: 297,
              columnNumber: 25
            }
          }, name, "(", position, ")"), __jsx(antd_lib_col__WEBPACK_IMPORTED_MODULE_5___default.a, {
            __self: _this3,
            __source: {
              fileName: _jsxFileName,
              lineNumber: 300,
              columnNumber: 25
            }
          }, __jsx(antd_lib_button__WEBPACK_IMPORTED_MODULE_4___default.a, {
            type: "link",
            danger: true,
            onClick: function onClick() {
              _this3.showDeleteConfirm(_id);
            },
            __self: _this3,
            __source: {
              fileName: _jsxFileName,
              lineNumber: 301,
              columnNumber: 27
            }
          }, "\uAD00\uB9AC \uB300\uC0C1 \uC81C\uC678")));
        },
        __self: this,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 291,
          columnNumber: 19
        }
      }), __jsx(antd_lib_row__WEBPACK_IMPORTED_MODULE_2___default.a, {
        style: {
          padding: '5px 0'
        },
        __self: this,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 314,
          columnNumber: 19
        }
      }, __jsx(antd_lib_col__WEBPACK_IMPORTED_MODULE_5___default.a, {
        span: "10",
        style: {
          paddingRight: '5px'
        },
        __self: this,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 315,
          columnNumber: 21
        }
      }, __jsx(antd_lib_input__WEBPACK_IMPORTED_MODULE_14___default.a, {
        placeholder: "\uAD6C\uC131\uC6D0 \uC774\uB984",
        ref: this.newMemberNameInput,
        __self: this,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 316,
          columnNumber: 23
        }
      })), __jsx(antd_lib_col__WEBPACK_IMPORTED_MODULE_5___default.a, {
        span: "10",
        style: {
          paddingRight: '5px'
        },
        __self: this,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 318,
          columnNumber: 21
        }
      }, __jsx(antd_lib_input__WEBPACK_IMPORTED_MODULE_14___default.a, {
        placeholder: "\uAD6C\uC131\uC6D0 \uC9C1\uAE09",
        ref: this.newMemberPositionInput,
        __self: this,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 319,
          columnNumber: 23
        }
      })), __jsx(antd_lib_col__WEBPACK_IMPORTED_MODULE_5___default.a, {
        span: "4",
        __self: this,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 321,
          columnNumber: 21
        }
      }, __jsx(antd_lib_button__WEBPACK_IMPORTED_MODULE_4___default.a, {
        type: "primary",
        onClick: this.addMember,
        __self: this,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 322,
          columnNumber: 23
        }
      }, "\uCD94\uAC00\uD558\uAE30"))))) : null, __jsx(antd_lib_button__WEBPACK_IMPORTED_MODULE_4___default.a, {
        type: "primary",
        onClick: function onClick() {
          axios__WEBPACK_IMPORTED_MODULE_18___default.a.post('/api/logout').then(function (rs) {
            next_router__WEBPACK_IMPORTED_MODULE_20___default.a.push('/');
          });
        },
        __self: this,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 331,
          columnNumber: 13
        }
      }, "\uB85C\uADF8\uC544\uC6C3"))), __jsx(antd_lib_row__WEBPACK_IMPORTED_MODULE_2___default.a, {
        style: {
          padding: '16px 8px'
        },
        __self: this,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 343,
          columnNumber: 9
        }
      }, __jsx(antd_lib_col__WEBPACK_IMPORTED_MODULE_5___default.a, {
        __self: this,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 344,
          columnNumber: 11
        }
      }, __jsx(antd_lib_row__WEBPACK_IMPORTED_MODULE_2___default.a, {
        className: "date-nav-box",
        __self: this,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 345,
          columnNumber: 13
        }
      }, __jsx(antd_lib_button__WEBPACK_IMPORTED_MODULE_4___default.a, {
        icon: __jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_19__["LeftOutlined"], {
          __self: this,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 347,
            columnNumber: 23
          }
        }),
        onClick: function onClick() {
          var viewDate = _this3.state.viewDate;

          _this3.onChangeDatePicker(viewDate.subtract(1, 'month').clone());
        },
        __self: this,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 346,
          columnNumber: 15
        }
      }), __jsx(antd_lib_date_picker__WEBPACK_IMPORTED_MODULE_1___default.a, {
        onChange: this.onChangeDatePicker,
        format: "YYYY-MM",
        value: viewDate,
        picker: "month",
        style: {
          marginLeft: '-1px'
        },
        __self: this,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 353,
          columnNumber: 15
        }
      }), __jsx(antd_lib_button__WEBPACK_IMPORTED_MODULE_4___default.a, {
        icon: __jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_19__["RightOutlined"], {
          __self: this,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 363,
            columnNumber: 23
          }
        }),
        style: {
          marginLeft: '-1px'
        },
        onClick: function onClick() {
          var viewDate = _this3.state.viewDate;

          _this3.onChangeDatePicker(viewDate.add(1, 'month').clone());
        },
        __self: this,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 362,
          columnNumber: 15
        }
      })), daysList.map(function (item) {
        return __jsx(antd_lib_row__WEBPACK_IMPORTED_MODULE_2___default.a, {
          key: item.format,
          className: "day-item day-".concat(item.day),
          justify: "center",
          align: "middle",
          __self: _this3,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 375,
            columnNumber: 17
          }
        }, __jsx(antd_lib_col__WEBPACK_IMPORTED_MODULE_5___default.a, {
          className: "text-center",
          span: "12",
          __self: _this3,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 376,
            columnNumber: 19
          }
        }, item.number), __jsx(antd_lib_col__WEBPACK_IMPORTED_MODULE_5___default.a, {
          className: "text-center",
          span: "12",
          __self: _this3,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 379,
            columnNumber: 19
          }
        }, item.dayStr));
      })), __jsx(antd_lib_col__WEBPACK_IMPORTED_MODULE_5___default.a, {
        style: {
          display: 'flex',
          overflow: 'auto',
          flex: 1
        },
        __self: this,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 386,
          columnNumber: 11
        }
      }, __jsx(antd_lib_row__WEBPACK_IMPORTED_MODULE_2___default.a, {
        style: {
          flexFlow: 'row'
        },
        __self: this,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 387,
          columnNumber: 13
        }
      }, viewMemberList.map(function (member) {
        console.log(member);
        return __jsx(antd_lib_col__WEBPACK_IMPORTED_MODULE_5___default.a, {
          key: member._id,
          className: "member-attendance-box",
          __self: _this3,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 391,
            columnNumber: 19
          }
        }, __jsx(antd_lib_row__WEBPACK_IMPORTED_MODULE_2___default.a, {
          className: "header-item",
          align: "middle",
          __self: _this3,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 392,
            columnNumber: 21
          }
        }, __jsx(antd_lib_col__WEBPACK_IMPORTED_MODULE_5___default.a, {
          className: "text-center",
          span: "24",
          __self: _this3,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 393,
            columnNumber: 23
          }
        }, member.name, " (", member.position, ")")), daysList.map(function (date) {
          var times = member.attendance[date.format];
          times = times ? times : {};
          console.log(isAdmin);

          if (isAdmin) {
            var startMoment;
            var endMoment;

            if (times.start) {
              startMoment = moment__WEBPACK_IMPORTED_MODULE_21___default()();
              startMoment.hour(times.start.split(':')[0]);
              startMoment.minute(times.start.split(':')[1]);
            }

            if (times.end) {
              endMoment = moment__WEBPACK_IMPORTED_MODULE_21___default()();
              endMoment.hour(times.end.split(':')[0]);
              endMoment.minute(times.end.split(':')[1]);
            }

            return __jsx(antd_lib_row__WEBPACK_IMPORTED_MODULE_2___default.a, {
              key: date.format,
              className: "day-item day-".concat(date.day),
              justify: "center",
              __self: _this3,
              __source: {
                fileName: _jsxFileName,
                lineNumber: 415,
                columnNumber: 27
              }
            }, __jsx(antd_lib_col__WEBPACK_IMPORTED_MODULE_5___default.a, {
              className: "time-box hour",
              span: "12",
              __self: _this3,
              __source: {
                fileName: _jsxFileName,
                lineNumber: 416,
                columnNumber: 29
              }
            }, __jsx(antd_lib_time_picker__WEBPACK_IMPORTED_MODULE_0___default.a, {
              value: startMoment ? startMoment.clone() : '',
              format: 'HH:mm',
              size: "small",
              placeholder: "\uCD9C\uADFC",
              onChange: function onChange(e, value) {
                _this3.onChangeTimePicker(value, member, date, 'start');
              },
              __self: _this3,
              __source: {
                fileName: _jsxFileName,
                lineNumber: 417,
                columnNumber: 31
              }
            })), __jsx(antd_lib_col__WEBPACK_IMPORTED_MODULE_5___default.a, {
              className: "time-box",
              span: "12",
              __self: _this3,
              __source: {
                fileName: _jsxFileName,
                lineNumber: 427,
                columnNumber: 29
              }
            }, __jsx(antd_lib_time_picker__WEBPACK_IMPORTED_MODULE_0___default.a, {
              value: endMoment ? endMoment.clone() : '',
              format: 'HH:mm',
              size: "small",
              placeholder: "\uD1F4\uADFC",
              onChange: function onChange(e, value) {
                _this3.onChangeTimePicker(value, member, date, 'end');
              },
              __self: _this3,
              __source: {
                fileName: _jsxFileName,
                lineNumber: 428,
                columnNumber: 31
              }
            })));
          } else {
            return __jsx(antd_lib_row__WEBPACK_IMPORTED_MODULE_2___default.a, {
              key: date.format,
              className: "day-item day-".concat(date.day, " text-center"),
              justify: "center",
              __self: _this3,
              __source: {
                fileName: _jsxFileName,
                lineNumber: 442,
                columnNumber: 27
              }
            }, __jsx(antd_lib_col__WEBPACK_IMPORTED_MODULE_5___default.a, {
              className: "time-box hour",
              span: "12",
              __self: _this3,
              __source: {
                fileName: _jsxFileName,
                lineNumber: 443,
                columnNumber: 29
              }
            }, times.start ? times.start : '-'), __jsx(antd_lib_col__WEBPACK_IMPORTED_MODULE_5___default.a, {
              className: "time-box",
              span: "12",
              __self: _this3,
              __source: {
                fileName: _jsxFileName,
                lineNumber: 446,
                columnNumber: 29
              }
            }, times.end ? times.end : '-'));
          }
        }));
      })))));
    }
  }]);

  return Main;
}(react__WEBPACK_IMPORTED_MODULE_16___default.a.Component); // TODO: 로그인 처리는 HOC에서


Object(_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_13__["default"])(Main, "getInitialProps", void 0);

Main.getInitialProps = function _callee3(_ref3) {
  var req, res;
  return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_6___default.a.async(function _callee3$(_context3) {
    while (1) {
      switch (_context3.prev = _context3.next) {
        case 0:
          req = _ref3.req, res = _ref3.res;
          return _context3.abrupt("return", {
            user: req.session.user
          });

        case 2:
        case "end":
          return _context3.stop();
      }
    }
  }, null, null, null, Promise);
};

/* harmony default export */ __webpack_exports__["default"] = (Object(next_session__WEBPACK_IMPORTED_MODULE_17__["withSession"])(Main));

/***/ })

})
//# sourceMappingURL=main.js.d4cd1b9f160469297c21.hot-update.js.map